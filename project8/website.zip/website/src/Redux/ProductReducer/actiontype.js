export const Load="Load"
export const Data="Data"
export const Error="Error"