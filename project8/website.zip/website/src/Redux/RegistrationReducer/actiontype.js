export const RegLoad="IsLoading"
export const Regdata="data"
export const Regerror="error"
