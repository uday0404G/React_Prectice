export const userdata="userdata" 
export const UserLoad="userLoad"
export const UserError="UserError"
export const UserDelete="UserDelete"